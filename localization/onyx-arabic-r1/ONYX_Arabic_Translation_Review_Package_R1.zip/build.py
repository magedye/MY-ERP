#!/usr/bin/env python3
"""Reproducible, conservative localization QA for an ERPNext/Frappe/HRMS export.
This is NOT an automated semantic review of all existing translations.
Run from /mnt/data/onyx_arabic_release using the original files one level above.
"""
from __future__ import annotations
import csv, re, json, hashlib, html, collections, datetime, pathlib, io, zipfile

SRC=pathlib.Path('/mnt/data')
OUT=SRC/'onyx_arabic_release'
OUT.mkdir(exist_ok=True)

# Prefer the 02_المصطلحات_ووحدات_العمل.md terms for workflow distinctions.
# These are editorial recommendations, NOT formal business-owner signoff.
TERMS = {
'عام وواجهة النظام': r'''
DocType => نوع المستند
DocTypes => أنواع المستندات
Document => مستند
Documents => مستندات
Document Type => نوع المستند
Document Name => اسم المستند
Field => حقل
Fields => حقول
Field Name => اسم الحقل
Field Type => نوع الحقل
Label => تسمية
Description => الوصف
Title => العنوان
Name => الاسم
Code => الرمز
ID => المعرّف
Status => الحالة
Type => النوع
Category => الفئة
Group => المجموعة
Company => الشركة
Branch => الفرع
Department => القسم
User => مستخدم
Users => المستخدمون
User ID => معرّف المستخدم
Role => دور
Roles => الأدوار
Permission => صلاحية
Permissions => الصلاحيات
User Permission => صلاحية المستخدم
Role Permission Manager => إدارة صلاحيات الأدوار
Read => قراءة
Write => كتابة
Create => إنشاء
Edit => تعديل
Save => حفظ
Delete => حذف
Cancel => إلغاء
Cancelled => ملغى
Draft => مسودة
Submitted => مثبّت
Approved => معتمد
Rejected => مرفوض
Pending => قيد الانتظار
Open => مفتوح
Closed => مغلق
Disabled => معطّل
Enabled => مفعّل
Active => نشط
Inactive => غير نشط
Mandatory => إلزامي
Required => مطلوب
Optional => اختياري
Default => افتراضي
Defaults => القيم الافتراضية
Settings => الإعدادات
Preferences => التفضيلات
Details => التفاصيل
New => جديد
Add => إضافة
Add Row => إضافة صف
Print => طباعة
Export => تصدير
Import => استيراد
Report => تقرير
Reports => تقارير
Dashboard => لوحة المعلومات
List => قائمة
Form => نموذج
Attachment => مرفق
Attachments => المرفقات
Search => بحث
Filter => تصفية
Sort => فرز
Today => اليوم
Yesterday => أمس
Tomorrow => غدًا
Year => سنة
Month => شهر
Day => يوم
Date => التاريخ
From Date => من تاريخ
To Date => إلى تاريخ
Start Date => تاريخ البداية
End Date => تاريخ النهاية
Due Date => تاريخ الاستحقاق
Posting Date => تاريخ الترحيل
Reference => المرجع
Reference No => الرقم المرجعي
Remarks => ملاحظات
Note => ملاحظة
Notes => ملاحظات
Amount => المبلغ
Rate => سعر الوحدة
Qty => الكمية
Quantity => الكمية
Total => الإجمالي
Grand Total => الإجمالي النهائي
Net Total => الإجمالي الصافي
Discount => الخصم
Tax => ضريبة
Taxes => الضرائب
Currency => العملة
Exchange Rate => سعر الصرف
Is Group => مجموعة تجميعية
Row => صف
Rows => الصفوف
Result => النتيجة
Results => النتائج
Action => إجراء
Actions => إجراءات
Select => اختيار
Selected => محدّد
Clear => مسح
Refresh => تحديث
Reload => إعادة تحميل
Download => تنزيل
Upload => رفع
Uploading... => جارٍ الرفع...
Back => رجوع
Next => التالي
Previous => السابق
Close => إغلاق
Apply => تطبيق
Apply Filters => تطبيق عوامل التصفية
All => الكل
None => لا شيء
Yes => نعم
No => لا
True => صحيح
False => خطأ
Success => تم بنجاح
Error => خطأ
Warning => تحذير
Information => معلومات
Notification => إشعار
Notifications => الإشعارات
Workflow => سير العمل
Workflow State => حالة سير العمل
Workflow Action => إجراء سير العمل
Activity Log => سجل الأنشطة
Audit Trail => سجل التدقيق
Print Format => تنسيق الطباعة
Letter Head => ترويسة المراسلات
System Settings => إعدادات النظام
Data Import => استيراد البيانات
Data Export => تصدير البيانات
Naming Series => سلسلة الترقيم
Help => مساعدة
Help Center => مركز المساعدة
Submit => تثبيت
Amend => تعديل بعد الإلغاء
''',
'المحاسبة والمالية': r'''
Account => حساب
Accounts => الحسابات
Account Name => اسم الحساب
Account Number => رقم الحساب
Account Type => نوع الحساب
Account Head => الحساب المحاسبي
Account Balance => رصيد الحساب
Account Currency => عملة الحساب
Account Details => تفاصيل الحساب
Account Category => فئة الحساب
Account Data => بيانات الحساب
Account Opening Balance => الرصيد الافتتاحي للحساب
Account Closing Balance => الرصيد الختامي للحساب
Chart of Accounts => دليل الحسابات
General Ledger => دفتر الأستاذ العام
GL Entry => قيد الأستاذ العام
Journal Entry => قيد يومية
Journal Entries => قيود يومية
Journal Entry Account => حساب قيد اليومية
Journal Entry Template => قالب قيد اليومية
Journal Entry Type => نوع قيد اليومية
Trial Balance => ميزان المراجعة
Balance Sheet => الميزانية العمومية
Profit and Loss Statement => قائمة الأرباح والخسائر
Profit and Loss => الأرباح والخسائر
Cash Flow => التدفق النقدي
Cash Flow Statement => قائمة التدفقات النقدية
Cost Center => مركز تكلفة
Cost Centers => مراكز التكلفة
Accounting Dimension => بُعد محاسبي
Accounting Dimensions => الأبعاد المحاسبية
Debit => مدين
Credit => دائن
Debit Amount => المبلغ المدين
Credit Amount => المبلغ الدائن
Opening Balance => الرصيد الافتتاحي
Closing Balance => الرصيد الختامي
Bank => بنك
Bank Account => حساب بنكي
Cash => نقد
Payment Entry => سند قبض/صرف/تحويل
Payment Entries => سندات قبض/صرف/تحويل
Payment Entry Reference => مرجع سند القبض/الصرف/التحويل
Payment Entry Deduction => استقطاع سند القبض/الصرف/التحويل
Payment Method => طريقة السداد
Mode of Payment => وسيلة الدفع
Mode of Payment Account => حساب وسيلة الدفع
Payment Terms => شروط السداد
Payment Term => شرط السداد
Payment Term Name => اسم شرط السداد
Payment Terms Template => قالب شروط السداد
Payment Schedule => جدول السداد
Payment Schedules => جداول السداد
Payment Reconciliation => مطابقة المدفوعات
Payment Reconciliation Settings => إعدادات مطابقة المدفوعات
Bank Reconciliation => مطابقة البنك
Bank Reconciliation Tool => أداة مطابقة البنك
Bank Transaction => معاملة بنكية
Accounts Receivable => الذمم المدينة
Accounts Payable => الذمم الدائنة
Receivable => ذمم مدينة
Payable => ذمم دائنة
Budget => موازنة
Budgets => موازنات
Budget Distribution => توزيع الموازنة
Budget Amount => مبلغ الموازنة
Fiscal Year => سنة مالية
Fiscal Years => السنوات المالية
Accounting Period => فترة محاسبية
Period Closing Voucher => سند إقفال الفترة
Tax Category => فئة ضريبية
Tax Rule => قاعدة ضريبية
Sales Taxes and Charges Template => قالب ضرائب ورسوم المبيعات
Purchase Taxes and Charges Template => قالب ضرائب ورسوم المشتريات
Exchange Gain or Loss => ربح أو خسارة فروق الصرف
Exchange Gain / Loss => ربح/خسارة فروق الصرف
Rounding Adjustment => تسوية التقريب
Write Off => شطب رصيد
Advance Payment => دفعة مقدمة
Advance Paid (Company Currency) => الدفعة المقدمة المدفوعة (عملة الشركة)
Account Paid From => الحساب المدفوع منه
Account Paid To => الحساب المدفوع إليه
Account Paid From/To => حساب الدفع أو القبض
Customer Advances => دفعات مقدمة من العملاء
Cleared => تمت التسوية
Posted On => مُرحّل بتاريخ
''',
'المبيعات والمشتريات والعلاقات': r'''
Customer => عميل
Customers => العملاء
Customer Name => اسم العميل
Customer Group => مجموعة العملاء
Customer Groups => مجموعات العملاء
Customer Group Name => اسم مجموعة العملاء
Customer Defaults => الإعدادات الافتراضية للعميل
Customer Contact => جهة اتصال العميل
Customer Ledger => دفتر حساب العميل
Customer Ledger Summary => ملخص دفتر حساب العميل
Customer Warehouse => مخزن العميل
Customer Address => عنوان العميل
Customer Primary Address => عنوان العميل الرئيسي
Customer Primary Contact => جهة الاتصال الرئيسية للعميل
Customer Credit Limit => الحد الائتماني للعميل
Customer Credit Balance => الرصيد الدائن للعميل
Customer Currency => عملة العميل
Supplier => مورد
Suppliers => الموردون
Supplier Name => اسم المورد
Supplier Group => مجموعة الموردين
Supplier Groups => مجموعات الموردين
Sales Invoice => فاتورة مبيعات
Sales Invoices => فواتير المبيعات
Sales Invoice Item => بند فاتورة المبيعات
Sales Order => أمر بيع
Sales Orders => أوامر البيع
Sales Order Item => بند أمر البيع
Delivery Note => مذكرة تسليم
Delivery Note Item => بند مذكرة التسليم
Delivery Note No => رقم مذكرة التسليم
Delivery Note Trends => اتجاهات مذكرات التسليم
Delivery Notes => مذكرات التسليم
Quotation => عرض سعر
Quotations => عروض الأسعار
Sales Return => مرتجع مبيعات
Sales Person => مندوب مبيعات
Sales Partner => شريك مبيعات
Point of Sale => نقطة بيع
POS Invoice => فاتورة نقطة بيع
Purchase Invoice => فاتورة شراء
Purchase Invoices => فواتير الشراء
Purchase Invoice Item => بند فاتورة الشراء
Purchase Order => أمر شراء
Purchase Orders => أوامر الشراء
Purchase Order Item => بند أمر الشراء
Purchase Order Date => تاريخ أمر الشراء
Purchase Order Trends => اتجاهات أوامر الشراء
Purchase Order Analysis => تحليل أوامر الشراء
Purchase Receipt => سند استلام مشتريات
Purchase Receipts => سندات استلام مشتريات
Purchase Receipt Item => بند سند استلام المشتريات
Purchase Receipt Detail => تفاصيل سند استلام المشتريات
Purchase Receipt Item Supplied => الصنف المُورَّد في سند الاستلام
Material Request => طلب مواد
Material Requests => طلبات مواد
Material Request Item => صنف طلب المواد
Material Request Detail => تفاصيل طلب المواد
Material Request No => رقم طلب المواد
Material Request Type => نوع طلب المواد
Purchase Return => مرتجع مشتريات
Buying => المشتريات
Selling => المبيعات
CRM => إدارة علاقات العملاء
Lead => عميل محتمل
Opportunity => فرصة بيع
Sales Invoice Trends => اتجاهات فواتير المبيعات
Purchase Invoice Trends => اتجاهات فواتير الشراء
Price List => قائمة أسعار
Price Lists => قوائم الأسعار
Price List Rate => سعر قائمة الأسعار
Pricing Rule => قاعدة تسعير
Pricing Rules => قواعد التسعير
Invoice => فاتورة
Invoices => الفواتير
Invoice No => رقم الفاتورة
Invoice Number => رقم الفاتورة
Invoice Date => تاريخ الفاتورة
Invoice Grand Total => الإجمالي النهائي للفاتورة
''',
'المخزون والتصنيع': r'''
Item => صنف
Items => الأصناف
Item Name => اسم الصنف
Item Code => رمز الصنف
Item Group => مجموعة الأصناف
Item Groups => مجموعات الأصناف
Item Price => سعر الصنف
Item Prices => أسعار الأصناف
Item Reorder => إعادة طلب الصنف
Item Tax => ضريبة الصنف
Item Tax Rate => معدل ضريبة الصنف
Item Tax Template => قالب ضريبة الصنف
Item Tax Template Detail => تفاصيل قالب ضريبة الصنف
Item Variant => متغير الصنف
Item Variants => متغيرات الأصناف
Item Variant Attribute => خاصية متغير الصنف
Item Variant Details => تفاصيل متغير الصنف
Item Weight Details => تفاصيل وزن الصنف
UOM => وحدة القياس
Stock UOM => وحدة قياس المخزون
UOM Conversion Detail => تفاصيل تحويل وحدة القياس
Warehouse => مخزن
Warehouses => المخازن
Warehouse Name => اسم المخزن
Warehouse Type => نوع المخزن
Warehouse Group => مجموعة المخازن
Stock => مخزون
Inventory => المخزون
Stock Entry => حركة مخزون
Stock Entries => حركات المخزون
Stock Entry Type => نوع حركة المخزون
Stock Balance => رصيد المخزون
Stock Ledger => دفتر حركة المخزون
Stock Ledger Entry => قيد دفتر حركة المخزون
Stock Reconciliation => تسوية المخزون
Stock Reconciliation Item => بند تسوية المخزون
Stock Value => قيمة المخزون
Stock Qty => كمية المخزون
Stock Quantity => كمية المخزون
Available Stock => المخزون المتاح
Actual Qty => الكمية الفعلية
Projected Qty => الكمية المتوقعة
Reserved Qty => الكمية المحجوزة
Valuation Rate => معدل تقييم المخزون
Valuation Method => طريقة تقييم المخزون
Serial No => الرقم التسلسلي
Serial Number => الرقم التسلسلي
Serial Nos => الأرقام التسلسلية
Batch => تشغيلة
Batch No => رقم التشغيلة
Batch Nos => أرقام التشغيلات
Batch ID => معرّف التشغيلة
Batch Qty => كمية التشغيلة
Batch Quantity => كمية التشغيلة
Batch Size => حجم التشغيلة
Batch Expiry Date => تاريخ انتهاء صلاحية التشغيلة
Batch Number Series => سلسلة ترقيم التشغيلات
Batch UOM => وحدة قياس التشغيلة
Serial and Batch Bundle => حزمة الأرقام التسلسلية والتشغيلات
Landed Cost Voucher => سند تكلفة إضافية للمخزون
Pick List => قائمة الانتقاء
Stock Settings => إعدادات المخزون
Stock and Account Value Comparison => مقارنة قيمة المخزون والحسابات
Material Transfer => نقل مواد
Material Issue => صرف مواد
Material Receipt => استلام مواد
Bill of Materials => قائمة المواد
BOM => قائمة المواد
Work Order => أمر تصنيع
Work Orders => أوامر التصنيع
Job Card => بطاقة عمل
Operation => عملية تصنيع
Workstation => محطة عمل
Routing => مسار التصنيع
Production Plan => خطة إنتاج
Manufacturing Settings => إعدادات التصنيع
Production Item => صنف إنتاج
Quality Inspection => فحص جودة
Quality Inspection Template => قالب فحص الجودة
Subcontracting Order => أمر تصنيع لدى متعهد
''',
'الأصول الثابتة': r'''
Asset => أصل ثابت
Assets => الأصول الثابتة
Asset Name => اسم الأصل
Asset ID => معرّف الأصل
Asset Category => فئة الأصول
Asset Category Account => حساب فئة الأصول
Asset Category Name => اسم فئة الأصول
Asset Account => حساب الأصول الثابتة
Asset Depreciation => إهلاك الأصل
Asset Depreciation Schedule => جدول إهلاك الأصل
Asset Depreciation Ledger => دفتر إهلاك الأصول
Asset Depreciation Cost Center => مركز تكلفة إهلاك الأصل
Asset Depreciations and Balances => إهلاك الأصول وأرصدتها
Asset Value Adjustment => تعديل قيمة الأصل
Asset Repair => إصلاح الأصل
Asset Maintenance => صيانة الأصول
Asset Maintenance Log => سجل صيانة الأصول
Asset Movement => حركة الأصل
Asset Movement Item => بند حركة الأصل
Asset Disposal => استبعاد الأصل
Asset Capitalization => رسملة الأصول
Fixed Asset Register => سجل الأصول الثابتة
Finance Book => دفتر الإهلاك المالي
Fixed Asset => أصل ثابت
Asset Type => نوع الأصل
Asset Value => قيمة الأصل
Asset Owner => مالك الأصل
Asset Location => موقع الأصل
Asset Status => حالة الأصل
Asset Quantity => كمية الأصل
Asset Details => تفاصيل الأصل
Asset Settings => إعدادات الأصول
Asset Reports => تقارير الأصول
Asset Repair Purchase Invoice => فاتورة شراء إصلاح الأصل
Asset Received But Not Billed => أصل مستلم لم تُصدر فاتورته
Asset Finance Book => دفتر الإهلاك المالي للأصل
''',
'الموارد البشرية والرواتب': r'''
Employee => موظف
Employees => الموظفون
Employee Name => اسم الموظف
Employee Number => رقم الموظف
Employee ID => معرّف الموظف
Employee Advance => سلفة موظف
Employee Advances => سلف الموظفين
Employee Group => مجموعة الموظفين
Employee Grade => درجة الموظف
Employee Journey => المسار الوظيفي للموظف
Employee Separation => إنهاء خدمة الموظف
Employee Checkin => تسجيل دخول/خروج الموظف
Employee Check-in => تسجيل دخول/خروج الموظف
Department => القسم
Designation => المسمى الوظيفي
Employment Type => نوع التوظيف
Leave Application => طلب إجازة
Leave Applications => طلبات الإجازة
Leave Type => نوع الإجازة
Leave Policy => سياسة الإجازات
Leave Policy Assignment => تعيين سياسة الإجازات
Leave Allocation => تخصيص رصيد الإجازات
Leave Balance => رصيد الإجازات
Leave Period => فترة الإجازات
Holiday List => قائمة العطلات
Holiday List Assignment => تعيين قائمة العطلات
Shift Type => نوع الوردية
Shift Assignment => تعيين الوردية
Shift => وردية
Attendance => الحضور
Attendance Request => طلب تسجيل حضور
Auto Attendance => الحضور الآلي
Salary Slip => كشف راتب
Salary Slips => كشوف الرواتب
Salary Structure => هيكل الراتب
Salary Structure Assignment => تعيين هيكل الراتب
Salary Component => بند الراتب
Salary Components => بنود الراتب
Payroll Entry => مسير الرواتب
Payroll Period => فترة الرواتب
Payroll Settings => إعدادات الرواتب
Payroll Dashboard => لوحة معلومات الرواتب
HR Dashboard => لوحة معلومات الموارد البشرية
HR Settings => إعدادات الموارد البشرية
Promotion => ترقية وظيفية
Gratuity => مكافأة نهاية الخدمة
Full and Final Statement => كشف التسوية النهائية
Job Requisition => طلب شاغر وظيفي
Job Applicant => متقدم لوظيفة
Job Application => طلب توظيف
Interview => مقابلة شخصية
Interview Round => جولة مقابلة
Interview Rounds => جولات المقابلة
Interview Feedback => تقييم المقابلة
Expense Claim => مطالبة مصروفات
Expense Claims => مطالبات المصروفات
Expense Claim Detail => تفاصيل مطالبة المصروفات
Employee Benefit => ميزة موظف
Overtime => عمل إضافي
Half Day => نصف يوم
Absent => غائب
Present => حاضر
On Leave => في إجازة
Leave Without Pay => إجازة غير مدفوعة الأجر
Unpaid Leave => إجازة غير مدفوعة الأجر
Working Days => أيام العمل
Payment Days => أيام استحقاق الأجر
Base & Variable => أساسي ومتغير
''',
'المشاريع والخدمات': r'''
Project => مشروع
Projects => المشاريع
Project Name => اسم المشروع
Project Type => نوع المشروع
Project Template => قالب المشروع
Project Summary => ملخص المشروع
Project Status => حالة المشروع
Project Manager => مدير المشروع
Project Reports => تقارير المشاريع
Task => مهمة
Tasks => المهام
Task Type => نوع المهمة
Task Name => اسم المهمة
Task Status => حالة المهمة
Timesheet => سجل ساعات العمل
Timesheets => سجلات ساعات العمل
Activity Type => نوع النشاط
Activity Cost => تكلفة النشاط
Estimated Cost => التكلفة التقديرية
Progress => التقدم
Completion => الإنجاز
''',
}

# Extra carefully scoped corrections for short UI phrases / descriptions absent from corpus glossaries.
SPECIAL = r'''
A bank account of yours or of a customer or supplier. => حساب بنكي يخصك أو يخص أحد العملاء أو الموردين.
A bill from a supplier for what you bought. => فاتورة من المورد عن مشترياتك.
A bill to a customer for what you sold. => فاتورة للعميل عن مبيعاتك.
A branch of your company. => فرع تابع لشركتك.
A brand your items are sold under. => علامة تجارية تُباع الأصناف باسمها.
A company or person you buy goods or services from. => شركة أو شخص تشتري منه سلعًا أو خدمات.
A company or person you sell goods or services to. => شركة أو شخص تبيع له سلعًا أو خدمات.
A company that makes the items you buy or sell. => شركة تصنع الأصناف التي تشتريها أو تبيعها.
A customer's confirmed order. => طلب شراء مؤكّد من العميل.
A date range you can close so no one posts into it. => نطاق زمني يمكن إقفاله لمنع ترحيل المعاملات خلاله.
A department of your company. => قسم تابع لشركتك.
A group of units of an item made or received together. => مجموعة وحدات من الصنف جرى إنتاجها أو استلامها معًا.
A grouping of calls, like sales or support. => تصنيف للمكالمات مثل المبيعات أو الدعم.
A grouping of inspection parameters. => مجموعة من معايير الفحص.
A grouping of issues, like billing or technical. => تصنيف للمشكلات، مثل الفوترة أو المشكلات الفنية.
A grouping of projects, like internal or external. => مجموعة للمشاريع، مثل المشاريع الداخلية أو الخارجية.
A grouping of tasks, like bug or feature. => تصنيف للمهام، مثل إصلاح عطل أو تطوير ميزة.
A grouping of units, like weight or length. => مجموعة لوحدات القياس، مثل الوزن أو الطول.
A grouping of warehouses, like transit or store. => مجموعة للمخازن، مثل مخازن العبور أو التخزين.
A job title, like manager or accountant. => مسمى وظيفي، مثل مدير أو محاسب.
A kind of workstation, with its costs. => نوع محطة عمل مع تكاليفها.
A machine or place where operations are done. => آلة أو موقع تُنفذ فيه عمليات التصنيع.
A meeting booked with a lead or customer. => اجتماع مجدول مع عميل محتمل أو عميل.
A parcel size you ship often. => حجم طرد تستخدمه للشحن بصورة متكررة.
A parcel you send through a carrier. => طرد ترسله عبر شركة نقل.
A periodic check of how a quality goal is going. => مراجعة دورية لمدى التقدم في تحقيق هدف جودة.
A person or company that owns shares in your company. => شخص أو شركة تمتلك أسهمًا في شركتك.
A phone call made or received. => مكالمة هاتفية صادرة أو واردة.
A piece of work to be done, often part of a project. => عمل مطلوب تنفيذه، ويكون غالبًا جزءًا من مشروع.
A piece of work with tasks, time and costs. => عمل يضم مهامًا ومددًا زمنية وتكاليف.
A place where you keep stock. => مكان لتخزين المخزون.
A place where your assets are kept. => مكان تُحفظ فيه أصولك.
A potential sale to a lead or customer. => فرصة بيع محتملة لعميل حالي أو محتمل.
A problem or question raised by a customer. => مشكلة أو استفسار يقدمه عميل.
A product or service you buy, sell or keep in stock. => سلعة أو خدمة تشتريها أو تبيعها أو تحتفظ بها في المخزون.
A progress update collected from the project team. => تحديث عن تقدم العمل يُجمع من فريق المشروع.
A record of maintenance done on an asset. => سجل أعمال الصيانة المنفذة على أصل.
A regular email summing up how the business is doing. => بريد إلكتروني دوري يلخص أداء المنشأة.
A reminder to a customer about an overdue invoice. => تذكير للعميل بشأن فاتورة متأخرة السداد.
A repair made to an asset, and what it cost. => إصلاح نُفذ على أصل مع تسجيل تكلفته.
A request to buy, transfer or make items. => طلب شراء أصناف أو نقلها أو تصنيعها.
A sale made at the point of sale. => عملية بيع تمت من نقطة البيع.
A saved set of accounts to start journal entries from. => مجموعة حسابات محفوظة لتسهيل إنشاء قيود اليومية.
A set of item prices for buying, selling or both. => مجموعة أسعار أصناف للمشتريات أو المبيعات أو كليهما.
A set of payment terms to apply to invoices and orders. => مجموعة شروط سداد تُطبَّق على الفواتير والأوامر.
A set of tasks to start new projects from. => مجموعة مهام جاهزة لبدء مشاريع جديدة.
A single unit of an item, tracked by its own number. => وحدة منفردة من صنف تُتابَع برقم تسلسلي خاص بها.
A step in making an item, like cutting or assembly. => مرحلة من تصنيع صنف، مثل القص أو التجميع.
A unit you measure items in, like kg or box. => وحدة لقياس الأصناف، مثل الكيلوجرام أو الصندوق.
A value a scorecard criterion is calculated from. => قيمة يُحسب منها معيار في بطاقة التقييم.
A vehicle's route to deliver to several customers. => مسار مركبة لتسليم الطلبات إلى عدة عملاء.
A view of your workstations and what each is doing. => عرض لمحطات العمل والعمليات التي تنفذها كل منها.
A visit to service or repair what a customer bought. => زيارة لخدمة أو إصلاح منتج اشتراه العميل.
Access => وصول
Action completed => اكتمل الإجراء
Action failed. => فشل تنفيذ الإجراء.
Add Aggregate => إضافة تجميع
Add Filter => إضافة عامل تصفية
Add Group By => إضافة تجميع حسب
Add More => إضافة المزيد
Add Section => إضافة قسم
Add User => إضافة مستخدم
Add User Permission => إضافة صلاحية مستخدم
Add attachment => إضافة مرفق
Add card => إضافة بطاقة
Add role => إضافة دور
Added Roles => الأدوار المضافة
Added Widgets => الأدوات المضافة
Advanced Condition => شرط متقدم
Advanced Expression using Python => تعبير متقدم باستخدام Python
Aggregate => تجميع
All Results => جميع النتائج
All apps => جميع التطبيقات
Allow Unregistered Events => السماح بالأحداث غير المسجلة
Permission => صلاحية
Unlink Payment => إلغاء ربط السداد
Duplicate Job Requisition => تكرار طلب الشاغر الوظيفي
Enter Interview Round => أدخل جولة المقابلة
Job Application Route => مسار طلب التوظيف
Leave and Expense Claim Settings => إعدادات الإجازات ومطالبات المصروفات
No attendance records to create => لا توجد سجلات حضور لإنشائها
Select Interview Round First => اختر جولة المقابلة أولًا
Source and Rating => المصدر والتقييم
This method is only meant for developer mode => هذه الطريقة مخصصة لوضع المطور فقط
Round Name => اسم الجولة
'''

# Explicit phrase translations for business-critical mismatches.
OVERRIDES = r'''
Account with child nodes cannot be converted to ledger => لا يمكن تحويل حساب له حسابات فرعية إلى حساب حركة.
Account with child nodes cannot be set as ledger => لا يمكن تعيين حساب له حسابات فرعية كحساب حركة.
Account with existing transaction can not be deleted => لا يمكن حذف حساب يحتوي على معاملات مسجلة.
Asset submitted => تم تثبيت مستند الأصل
Asset scrapped => تم تخريد الأصل
Asset Owner Company => الشركة المالكة للأصل
Asset Shift Allocation => توزيع الورديات على الأصل
Asset Shift Factor => معامل وردية الأصل
Batch Description => وصف التشغيلة
Batch Details => تفاصيل التشغيلة
Batch Item Expiry Status => حالة صلاحية تشغيلة الصنف
Batch Tracked => متتبع بالتشغيلة
Customer Contact Email => البريد الإلكتروني للعميل
Customer Group Name => اسم مجموعة العملاء
Customer PO => أمر شراء العميل
Customer PO Details => تفاصيل أمر شراء العميل
Delivery Note Packed Item => الصنف المعبأ في مذكرة التسليم
Invoice Grand Total => الإجمالي النهائي للفاتورة
Item Tax Amount Included in Value => قيمة ضريبة الصنف المضمنة في المبلغ
Item Tax Template Detail => تفاصيل قالب ضريبة الصنف
Item Reorder => إعادة طلب الصنف
Item Variant Settings => إعدادات متغيرات الأصناف
Maintenance Visit Purpose => غرض زيارة الصيانة
Payment Account => حساب السداد
Payment Amount => مبلغ السداد
Payment Entries => سندات قبض/صرف/تحويل
Payment Entry => سند قبض/صرف/تحويل
Payment Reconciliation Invoice => فاتورة مطابقة المدفوعات
Payment Reconciliation Payment => دفعة مطابقة المدفوعات
Payment Gateway Account => حساب بوابة الدفع
Payment Gateway Details => تفاصيل بوابة الدفع
Payment Term Outstanding => المستحق وفق شرط السداد
Payment Term Name => اسم شرط السداد
Payment Request => طلب سداد
Payment Reference => مرجع السداد
Payment References => مراجع السداد
Payment Ledger => دفتر المدفوعات
Payment Ledger Entry => قيد دفتر المدفوعات
Purchase Invoice Advance => دفعة مقدمة لفاتورة الشراء
Purchase Order Trends => اتجاهات أوامر الشراء
Purchase Receipt Detail => تفاصيل سند استلام المشتريات
Rate => سعر الوحدة
Valuation Rate => معدل تقييم المخزون
Draft => مسودة
Stock => مخزون
Batch => تشغيلة
Journal Entry => قيد يومية
Stock Entry => حركة مخزون
'''


def parse_map(block):
    mapping={}
    for raw in block.splitlines():
        if not raw.strip() or raw.lstrip().startswith('#'):continue
        if ' => ' not in raw:raise ValueError('Invalid term line: '+raw)
        en, ar=raw.split(' => ',1)
        en,ar=en.strip(),ar.strip()
        if not en or not ar:raise ValueError('Empty term')
        if en in mapping and mapping[en]!=ar:raise ValueError('Conflicting translation: '+en)
        mapping[en]=ar
    return mapping

CATEGORY_MAP={cat:parse_map(block) for cat,block in TERMS.items()}
UNSCOPED={}
for cat, vals in CATEGORY_MAP.items():
    for en,ar in vals.items():
        if en in UNSCOPED and UNSCOPED[en][0]!=ar:
            # Different domains can have valid distinct translations; resolve by application.
            pass
        else:UNSCOPED.setdefault(en,(ar,cat))
SPECIAL_MAP=parse_map(SPECIAL)
OVERRIDE_MAP=parse_map(OVERRIDES)

def load_editorial_additions(path):
    app=None;mapping={}
    for lineno,raw in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        if not raw.strip() or raw.startswith('#'):continue
        if raw.startswith('@@'):
            app=raw[2:].strip()
            assert app in ('frappe','erpnext','hrms'),(lineno,app)
            continue
        assert app and ' => ' in raw,(lineno,raw)
        en,ar=raw.split(' => ',1)
        if (app,en) in mapping and mapping[app,en]!=ar:raise ValueError((lineno,en))
        mapping[app,en]=ar
    return mapping
EXTRA_MAP=load_editorial_additions(OUT/'editorial_additions.txt')
# A few original sentences contain broken placeholder/HTML signatures. Explicit
# full-message repairs are reviewed for exact source match and validated again.
FULL_MESSAGE={
 ('erpnext','Accounting Entry for {0}: {1} can only be made in currency: {2}'):'لا يمكن إنشاء القيد المحاسبي لـ{0}: {1} إلا بالعملة {2}.',
 ('erpnext','For row {0} in {1}. To include {2} in Item rate, rows {3} must also be included'):'في الصف {0} من {1}، لإدراج {2} ضمن سعر الصنف، يجب إدراج الصفوف {3} أيضًا.',
 ('erpnext','Please ensure {} account {} is a Receivable account.'):'يرجى التأكد من أن الحساب {} ({}) هو حساب ذمم مدينة.',
 ('erpnext','Please set an email id for the Lead {0}'):'يرجى تحديد عنوان بريد إلكتروني للعميل المحتمل {0}.',
 ('erpnext','Row #{0}: Journal Entry {1} does not have account {2} or already matched against another voucher'):'الصف #{0}: قيد اليومية {1} لا يحتوي على الحساب {2} أو تمت مطابقته مسبقًا مع مستند آخر.',
 ('erpnext','Row {0}: Party Type and Party is required for Receivable / Payable account {1}'):'الصف {0}: يلزم تحديد نوع الطرف والطرف للحساب {1} ضمن الذمم المدينة/الدائنة.',
 ('erpnext','Total Debit must be equal to Total Credit. The difference is {0}'):'يجب أن يتساوى إجمالي المدين وإجمالي الدائن. الفرق هو {0}.',
 ('erpnext','{0} {1}: Supplier is required against Payable account {2}'):'{0} {1}: يجب تحديد المورد مقابل حساب الذمم الدائنة {2}.',
 ('frappe','Cannot change state of Cancelled Document. Transition row {0}'):'لا يمكن تغيير حالة مستند ملغى. صف الانتقال {0}.',
 ('frappe',"JavaScript Format: frappe.query_reports['REPORTNAME'] = {}"):'تنسيق JavaScript: frappe.query_reports[\'REPORTNAME\'] = {}',
 ('frappe','{0} {1} cannot be "{2}". It should be one of "{3}"'):'لا يمكن أن تكون قيمة {0} {1} هي "{2}". يجب أن تكون واحدة من "{3}".',
 ('hrms','Leave Type {0} cannot be carry-forwarded'):'لا يمكن ترحيل رصيد نوع الإجازة {0} إلى الفترة التالية.',
 ('hrms','Advance Account is mandatory. Please set the <a href="/app/company/{0}#default_employee_advance_account" target="_blank">Default Employee Advance Account</a> in the Company record {0} and submit this document.'):'حساب السلف إلزامي. حدّد <a href="/app/company/{0}#default_employee_advance_account" target="_blank">حساب سلف الموظفين الافتراضي</a> في سجل الشركة {0}، ثم ثبّت المستند.',
 ('hrms','Choose how the hourly overtime amount is calculated:\n<ol style="padding-left:15px;"><li>Fixed Hourly Rate: A fixed, manually entered hourly rate.</li>\n<li>Salary Component-Based:\n\n(Sum of selected component amounts) ÷ (Payment Days) ÷ (Standard Daily Hours)</li></ol>'):'اختر طريقة احتساب مبلغ ساعة العمل الإضافي:\n<ol style="padding-left:15px;"><li>سعر ساعة ثابت: سعر يُدخل يدويًا.</li>\n<li>بحسب بنود الراتب:\n\n(مجموع مبالغ البنود المحددة) ÷ (أيام استحقاق الأجر) ÷ (ساعات العمل اليومية القياسية)</li></ol>',
 ('erpnext','Not allowed to update stock transactions older than {0}'):'لا يُسمح بتحديث حركات المخزون الأقدم من {0}.',
 ('erpnext','Warehouse {0} does not belong to company {1}'):'المخزن {0} لا يتبع الشركة {1}.',
 ('erpnext','Show Warehouse-wise Stock'):'عرض المخزون حسب المخزن',
 ('erpnext','Project wise Stock Tracking'):'تتبع المخزون حسب المشروع',
 ('erpnext','System will notify to increase or decrease quantity or amount'):'سيُرسل النظام إشعارًا بزيادة الكمية أو المبلغ أو خفضهما.',
 ('erpnext','Open To Do'):'المهام المفتوحة',
 ('erpnext','Item {0}: {1} qty produced.'):'الصنف {0}: الكمية المنتجة {1}.',
 ('erpnext','From Time'):'من الوقت',
 ('erpnext','Please set default Cash or Bank account in Mode of Payment {0}'):'يرجى تحديد حساب النقد أو البنك الافتراضي في وسيلة الدفع {0}.',
 ('erpnext','Purchase Order number required for Item {0}'):'رقم أمر الشراء مطلوب للصنف {0}.',
 ('hrms','No Employee Found'):'لم يُعثر على أي موظف.',
}

# Domains and default rules. Handle ambiguous labels conservatively.
AMBIGUOUS={'Item','Items','Rate','Submit','Amend','Batch','Draft','Asset','Project','Advance Payment','Posting Date','Depreciation','Account Head','Payment Entry','Cancelled','Submitted'}

SOURCE_FILES = {'erpnext':'ERPNext_Arabic_Translations.csv','frappe':'Frappe_Arabic_Translations.csv'}
HEADERS=['English Text (msgid)','Arabic Text (msgstr)','Context (msgctxt)','Description / Note','Source Location']
rows=[]
source_fingerprints={}
for app, filename in SOURCE_FILES.items():
    p=SRC/filename
    source_fingerprints[filename]=hashlib.sha256(p.read_bytes()).hexdigest()
    with p.open(encoding='utf-8-sig',newline='') as f:
        rdr=csv.DictReader(f)
        assert rdr.fieldnames==HEADERS
        for d in rdr:
            rows.append(dict(app=app,source_file=filename,src=d[HEADERS[0]],old=d[HEADERS[1]],context=d[HEADERS[2]],note=d[HEADERS[3]],location=d[HEADERS[4]]))
p=SRC/'all_translations.csv';source_fingerprints[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
with p.open(encoding='utf-8-sig',newline='') as f:
    rdr=csv.DictReader(f)
    assert rdr.fieldnames==['App','Context','Source (msgid)','Translation (msgstr)']
    all_rows=list(rdr)
for d in all_rows:
    if d['App']=='hrms':
        rows.append(dict(app='hrms',source_file='all_translations.csv',src=d['Source (msgid)'],old=d['Translation (msgstr)'],context=d['Context'],note='',location=''))
assert len(rows)==len(all_rows)
key_of=lambda r:(r['app'],r['src'],r['context'])
assert len({key_of(r) for r in rows})==len(rows)
source_by_key={(d['App'],d['Source (msgid)'],d['Context']):d['Translation (msgstr)'] for d in all_rows}
assert all(source_by_key[key_of(r)]==r['old'] for r in rows)

# The same source/context in another app may safely reuse its proven, nonempty translation,
# if the source has no domain ambiguity. This is NOT a proof of semantic review.
by_key=collections.defaultdict(set)
for r in rows:
    if r['old'].strip():by_key[(r['src'],r['context'])].add(r['old'])

# Formatting risk precheck: count placeholders literally, not escaped braces.
BRACE=re.compile(r'(?<!\{)\{(?:[0-9]*|[a-zA-Z_][a-zA-Z0-9_\.]*)(?:![ras])?(?::[^{}]+)?\}(?!\})')
PERCENT=re.compile(r'%(?:\([a-zA-Z_][a-zA-Z0-9_]*\))?[#+\-0]*\d*(?:\.\d+)?[sdfcr]')
HTML_TAG=re.compile(r'<\s*/?\s*([a-zA-Z][\w-]*)\b[^>]*>')

def signatures(s):
    return (collections.Counter(BRACE.findall(s)),collections.Counter(PERCENT.findall(s)))

def risk_counts(src,dst):
    if not dst.strip():return []
    issues=[]
    a,b=signatures(src),signatures(dst)
    if a[0]!=b[0]:issues.append('BRACE_PLACEHOLDERS')
    if a[1]!=b[1]:issues.append('PRINTF_PLACEHOLDERS')
    # Structural tag-count discrepancies only where source has HTML tags.
    if HTML_TAG.search(src):
        at=collections.Counter(x.lower() for x in HTML_TAG.findall(src))
        bt=collections.Counter(x.lower() for x in HTML_TAG.findall(dst))
        if at!=bt:issues.append('HTML_TAG_SET')
    # Source leading/trailing whitespace is significant for fragment-style strings.
    if src and (src[0].isspace() or src[-1].isspace()):
        a1=re.match(r'^\s*',src).group();a2=re.search(r'\s*$',src).group()
        b1=re.match(r'^\s*',dst).group();b2=re.search(r'\s*$',dst).group()
        if a1!=b1 or a2!=b2:issues.append('BOUNDARY_WHITESPACE')
    return issues

# String-specific context rule that may override the universal glossary.
def choose_term(r):
    src, app,ctx,loc=r['src'],r['app'],r['context'],r['location']
    if not src.strip():return None
    key=src.strip()
    if (app,key) in FULL_MESSAGE:return FULL_MESSAGE[app,key],'FULL_MESSAGE_VERIFIED'
    if '\n' in src:return None
    if (app,key) in EXTRA_MAP:return EXTRA_MAP[app,key],'EDITORIAL_EXACT'
    if key in OVERRIDE_MAP:
        if key=='Batch' and app!='erpnext':return None
        if key=='Rate' and app!='erpnext':return None
        if key=='Asset' and app!='erpnext':return None
        if key=='Stock' and app!='erpnext':return None
        if key=='Draft' and app!='frappe':
            # HRMS/ERPNext statuses can use the same standard if exact match.
            pass
        return OVERRIDE_MAP[key], 'EXPLICIT_CORRECTION'
    if key=='Submit':
        if app!='frappe':return None
        if ctx in ('','Button in list view actions menu'):return 'تثبيت','CONTEXT_SUBMIT_DOCUMENT'
        if 'password' in ctx.lower():return 'إرسال','CONTEXT_SUBMIT_FORM'
        return 'إرسال','CONTEXT_SUBMIT_FORM'
    if key=='Item':
        if app=='frappe':return 'عنصر','CONTEXT_GENERAL_UI'
        return 'صنف','DOMAIN_ITEM'
    if key=='Items':
        if app=='frappe':return 'عناصر','CONTEXT_GENERAL_UI'
        return 'الأصناف','DOMAIN_ITEM'
    if key=='Rate' and app!='erpnext':return None
    if key=='Batch' and app!='erpnext':return None
    if key=='Amend' and app=='frappe':return 'تعديل بعد الإلغاء','CONTEXT_DOCUMENT'
    if key in UNSCOPED:
        ar,cat=UNSCOPED[key]
        if key in ('Account Head','Rate') and app!='erpnext':return None
        if key in ('Submitted','Cancelled') and ctx and 'primary action' in ctx.lower():return None
        if key in ('Asset','Stock') and app=='frappe':return None
        return ar,'GLOSSARY_EXACT'
    if key in SPECIAL_MAP:return SPECIAL_MAP[key],'CURATED_UI_PHRASE'
    return None

# For stock batches, normalize only the operational 'Batch' concept; NOT payment batches.
BATCH_FORMS=[('بالدفعات','بالتشغيلات'),('الدفعات','التشغيلات'),('الدفعة','التشغيلة'),('لدفعة','لتشغيلة'),('بالدفعة','بالتشغيلة'),('دفعات','تشغيلات'),('دفعة','تشغيلة'),('الباتش','التشغيلة'),('باتش','تشغيلة')]
WAREHOUSE_FORMS=[('المستودعات','المخازن'),('مستودعات','مخازن'),('المستودع','المخزن'),('بالمستودع','بالمخزن'),('مستودع','مخزن')]

def normalize_orthography(s):
    # Only uncontroversial typing/hamza forms; never touch code/identifiers.
    subs=[('الإست','الاست'),('إست','است'),('الإتصال','الاتصال'),('إتصال','اتصال'),('الإختبار','الاختبار'),('إختبار','اختبار'),('الإختيار','الاختيار'),('إختيار','اختيار'),('الإفتراضي','الافتراضي'),('إفتراضي','افتراضي')]
    for old,new in subs:s=s.replace(old,new)
    return s

def safe_domain_normalization(r,text):
    src,loc,app=r['src'],r['location'],r['app']
    tags=[]
    if app=='erpnext' and re.search(r'\bBatches?\b',src,re.I) and re.search(r'/(stock|manufacturing)/',loc):
        before=text
        for o,n in BATCH_FORMS:text=text.replace(o,n)
        if before!=text:tags.append('BATCH_STOCK_CONTEXT')
    # Translate Warehouse consistently only if the English really refers to a warehouse.
    if re.search(r'\bWarehouses?\b',src,re.I) and app=='erpnext':
        before=text
        for o,n in WAREHOUSE_FORMS:text=text.replace(o,n)
        if before!=text:tags.append('WAREHOUSE_CONTEXT')
    # In the fixed-assets domain, depreciation is الإهلاك, not استهلاك inventory.
    if app=='erpnext' and re.search(r'\bDepreciation(s)?\b',src,re.I):
        before=text
        for o,n in [('الإستهلاك','الإهلاك'),('الاستهلاك','الإهلاك'),('إستهلاك','إهلاك'),('استهلاك','إهلاك')]:text=text.replace(o,n)
        if before!=text:tags.append('DEPRECIATION_CONTEXT')
    return text,tags

changelog=[]
qa_buckets=collections.Counter()
for r in rows:
    before=r['old'];result=before;causes=[]
    src=r['src'];orig_issues=risk_counts(src,before)
    choice=choose_term(r)
    if choice:
        preferred,why=choice
        # Exact labels only; preserve literal source boundary spaces, unlike common trim bugs.
        leading=re.match(r'^\s*',src).group();trailing=re.search(r'\s*$',src).group()
        new=leading+preferred+trailing
        if new!=result:
            # Never replace placeholders, HTML, or multiline labels with simple glossary snippets.
            if (why in ('FULL_MESSAGE_VERIFIED','EDITORIAL_EXACT') or (not signatures(src)[0] and not signatures(src)[1] and not HTML_TAG.search(src))):
                result=new;causes.append(why)
    elif not before.strip() and src.strip():
        # strict translation memory: identical source+context, a single clean nonempty option
        opts=by_key[(src,r['context'])]
        if len(opts)==1 and src.strip() not in AMBIGUOUS:
            candidate=next(iter(opts))
            if not risk_counts(src,candidate):
                result=candidate;causes.append('CROSS_APP_EXACT_TM')
    if result.strip():
        # Remove an objectively duplicated source text appended by old automated translation.
        # Remove clearly duplicated English source echoes from poor legacy MT, whether
        # written with literal backslash-n sequences or real line breaks.
        # Do not remove legitimate bilingual markup or Arabic second paragraphs.
        for separator in ('\\n<br>\\n', '\n<br>\n', '<br>', '<br> '):
            # Simplest proof: an appended source exactly repeats msgid.
            for echo in (src, html.escape(src)):
                if result.endswith(separator+echo) and re.search(r'[\u0600-\u06FF]',result[:-len(separator+echo)]):
                    result=result[:-len(separator+echo)];causes.append('REMOVE_DUPLICATED_SOURCE_ECHO')
                    break
            if 'REMOVE_DUPLICATED_SOURCE_ECHO' in causes:break
        if 'REMOVE_DUPLICATED_SOURCE_ECHO' not in causes and '\\n<br>\\n' in result:
            from difflib import SequenceMatcher
            prefix,tail=result.rsplit('\\n<br>\\n',1)
            a=' '.join(html.unescape(src).split())
            b=' '.join(html.unescape(tail).split())
            if (len(a)>20 and re.search(r'[\u0600-\u06FF]',prefix) and
                not re.search(r'[\u0600-\u06FF]',tail) and
                SequenceMatcher(None,a.casefold(),b.casefold()).ratio()>=0.92):
                result=prefix;causes.append('REMOVE_DUPLICATED_SOURCE_ECHO')
        # Avoid normalizing HTML/CSS source/code snippets or technical literals without Arabic.
        if re.search(r'[\u0600-\u06FF]',result):
            if not re.search(r'<[a-zA-Z][\w-]*',src):
                normalized=normalize_orthography(result)
                if normalized!=result:result=normalized;causes.append('SAFE_ARABIC_ORTHOGRAPHY')
            normalized,tags=safe_domain_normalization(r,result)
            if normalized!=result:result=normalized;causes.extend(tags)
    # Preserve intentional ASCII fragment padding in source and translated label.
    # Never trim or reshape technical markup/multiline strings.
    if result.strip() and src.strip() and '\n' not in src and '\t' not in src and not HTML_TAG.search(src):
        initial=re.match(r'^ *',src).group();final=re.search(r' *$',src).group()
        if initial or final:
            changed=initial+result.strip(' ')+final
            if changed!=result:result=changed;causes.append('PRESERVE_FRAGMENT_WHITESPACE')
    # Fail closed on introduced placeholder regressions / HTML structure / source whitespace.
    new_issues=risk_counts(src,result)
    new_regressions=set(new_issues)-set(orig_issues)
    if new_regressions:
        r['blocked_candidate']=result;r['blocked_reasons']=sorted(new_regressions)
        result=before;causes=[]
        qa_buckets['BLOCKED_EDIT']+=1
    r['new']=result
    r['changes']=list(dict.fromkeys(causes)) if result!=before else []
    if r['changes']:
        changelog.append(dict(App=r['app'],Source=r['src'],Context=r['context'],Before=before,After=result,Rules=';'.join(r['changes']),Location=r['location'],Source_File=r['source_file']))

# Separate output formats. Same five-column schema for each app to support traceability;
# hrms source CSV never supplied Description/Source Location; do not fabricate them.
output_files={}
for app in ('frappe','erpnext','hrms'):
    name=f'{app.upper() if app=="hrms" else app.capitalize()}_Arabic_Corrected.csv'
    # Explicit names suitable for case-sensitive file system (ERPNext capital N).
    if app=='erpnext':name='ERPNext_Arabic_Corrected.csv'
    elif app=='frappe':name='Frappe_Arabic_Corrected.csv'
    elif app=='hrms':name='HRMS_Arabic_Corrected.csv'
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f,lineterminator='\n');w.writerow(HEADERS)
        for r in rows:
            if r['app']==app:w.writerow([r['src'],r['new'],r['context'],r['note'],r['location']])
    output_files[app]=name

with (OUT/'Translation_Change_Log.csv').open('w',encoding='utf-8-sig',newline='') as f:
    cols=['App','Source','Context','Before','After','Rules','Location','Source_File'];w=csv.DictWriter(f,fieldnames=cols,lineterminator='\n');w.writeheader();w.writerows(changelog)

# Compile an auditable glossary: no false claim of human sign-off.
occurrences=collections.defaultdict(list)
for r in rows:occurrences[r['src'].strip()].append(r['app'])
all_gloss=[]
for cat,terms in CATEGORY_MAP.items():
    for en,ar in terms.items():
        avoid=''
        if en=='Draft':avoid='مشروع (Project)'
        if en=='Valuation Rate':avoid='معدل التقييم الحسابي دون توضيح المخزون؛ السعر التجاري'
        if en=='Submit':avoid='إرسال عندما يقصد تثبيت مستند محاسبي؛ اعتماد إداري دون Workflow'
        if en=='Batch':avoid='دفعة مالية عندما المقصود تشغيلة مخزنية'
        if en=='Payment Entry':avoid='تدوينات المدفوعات؛ سند صرف فقط'
        if en=='Warehouse':avoid='تفاوت مخزن/مستودع في الواجهة نفسها'
        if en=='Asset Depreciation':avoid='استهلاك المخزون'
        if en=='Budget':avoid='الميزانية العمومية'
        if en=='Item':avoid='بند/عنصر في سياق السجل المخزني؛ يختلف عن Item عام في Frappe'
        if en=='Delivery Note':avoid='حركة مخزون غير موثقة بديلًا عن مستند التسليم'
        if en=='Salary Slip':avoid='قسيمة راتب إذا كان الاصطلاح المؤسسي المعتمد كشف راتب'
        if en=='Project':avoid='مسودة (Draft)'
        if en=='Journal Entry':avoid='القيود اليومية بوصف المفرد'
        critical=cat in ('المحاسبة والمالية','الأصول الثابتة','الموارد البشرية والرواتب') or en in ('Submit','Batch','Item','Draft','Warehouse','Stock','Delivery Note','Payment Entry','Rate')
        usage='سياق الواجهة' if cat=='عام وواجهة النظام' else cat
        if en=='Submit':usage='تثبيت مستند DocType مع docstatus=1؛ النماذج العامة: إرسال'
        elif en=='Item':usage='ERPNext صنف مخزني؛ Frappe العام عنصر'
        elif en=='Batch':usage='تشغيلة المخزون؛ لا يطبق على دفعة المدفوعات'
        elif en=='Rate':usage='معدل/سعر الوحدة في مستندات البيع والمخزون؛ لا يشمل معدل الفائدة'
        elif en=='Asset':usage='سجل الأصل الثابت في ERPNext؛ ليس أي أصل معنوي عام'
        elif en=='Posting Date':usage='تاريخ الأثر المحاسبي/المخزني؛ لا يساوي تاريخ الإدخال'
        elif en=='Draft':usage='حالة المستند؛ ليست Project'
        all_gloss.append({'Term_English':en,'Preferred_Arabic':ar,'Domain':cat,'Usage_Context':usage,'Discouraged_Translations':avoid,'Evidence_Basis':'02_المصطلحات_ووحدات_العمل.md + مراجعة تحريرية' if en in ('DocType','Delivery Note','Valuation Rate','Stock Entry','Batch','Item','Salary Slip','Submit') else 'قرار توحيد تحريري لمشروع ERPNext', 'Approval_Status':'REQUIRES_DOMAIN_OWNER_APPROVAL' if critical else 'PROPOSED_EDITORIAL_STANDARD', 'Exact_Source_Count':len(occurrences[en]), 'Apps_Found':';'.join(sorted(set(occurrences[en]))), 'Review_Notes':'اعتماد تحريري مقترح؛ لا يوجد توقيع اعتماد من مالك العمل'})
# Add curated phrase translations to the glossary only when exact phrase exists; label them UI help.
for en,ar in SPECIAL_MAP.items():
    if en not in occurrences or en in {r['Term_English'] for r in all_gloss}:continue
    all_gloss.append({'Term_English':en,'Preferred_Arabic':ar,'Domain':'عبارات مساعدة في الواجهة','Usage_Context':'عبارة كاملة؛ لا تستخدم لاستبدال أجزاء من نصوص أخرى','Discouraged_Translations':'','Evidence_Basis':'توضيح تحريري مطابق للنص الإنجليزي','Approval_Status':'PROPOSED_EDITORIAL_STANDARD','Exact_Source_Count':len(occurrences[en]),'Apps_Found':';'.join(sorted(set(occurrences[en]))),'Review_Notes':'تُطبَّق عند تطابق النص بالكامل فقط'})
for (app,en),ar in EXTRA_MAP.items():
    if en not in occurrences or en in {r['Term_English'] for r in all_gloss} or len(en)>70:continue
    all_gloss.append({'Term_English':en,'Preferred_Arabic':ar,'Domain':'عبارات وأوامر الواجهة','Usage_Context':'ترجمة دقيقة للعبارة الكاملة في '+app,'Discouraged_Translations':'','Evidence_Basis':'مراجعة تحريرية للنص المطابق','Approval_Status':'PROPOSED_EDITORIAL_STANDARD','Exact_Source_Count':len(occurrences[en]),'Apps_Found':';'.join(sorted(set(occurrences[en]))),'Review_Notes':'لا تستبدل جزءًا من رسالة أخرى بهذه الصياغة'})
for en,ar in OVERRIDE_MAP.items():
    if en in {r['Term_English'] for r in all_gloss}:continue
    all_gloss.append({'Term_English':en,'Preferred_Arabic':ar,'Domain':'تصحيح مصطلح أو عبارة','Usage_Context':'العبارة الكاملة فقط','Discouraged_Translations':'','Evidence_Basis':'تصحيح تحريري للمخرج','Approval_Status':'REQUIRES_DOMAIN_OWNER_APPROVAL','Exact_Source_Count':len(occurrences[en]),'Apps_Found':';'.join(sorted(set(occurrences[en]))),'Review_Notes':'قد يتطلب مراجعة تخصصية'})
all_gloss.sort(key=lambda x:(x['Domain'],x['Term_English'].casefold()))
seen_terms=set();formal_gloss=[];phrase_memory=[]
for entry in all_gloss:
    # Glossary contains single terms/documents/fields and business concepts; longer
    # UI phrases live in separate translation memory for clarity of governance.
    target = formal_gloss if entry['Domain'] in CATEGORY_MAP else phrase_memory
    if target is formal_gloss and entry['Term_English'] in seen_terms:continue
    target.append(entry)
    if target is formal_gloss:seen_terms.add(entry['Term_English'])
with (OUT/'Curated_Translation_Memory_AR.csv').open('w',encoding='utf-8-sig',newline='') as f:
    cols=list(phrase_memory[0]);w=csv.DictWriter(f,fieldnames=cols,lineterminator='\n');w.writeheader();w.writerows(phrase_memory)
with (OUT/'Terminology_Glossary_AR.csv').open('w',encoding='utf-8-sig',newline='') as f:
    cols=list(all_gloss[0]);w=csv.DictWriter(f,fieldnames=cols,lineterminator='\n');w.writeheader();w.writerows(formal_gloss)

# Quality review queue: known original issues and meaningful unresolved missing lines.
qa=[]
for r in rows:
    src,old,new=r['src'],r['old'],r['new']
    issues=risk_counts(src,new)
    if not new.strip() and src.strip():issues.append('UNTRANSLATED')
    if new.strip() and not re.search(r'[\u0600-\u06FF]',new) and re.search(r'[a-zA-Z]',src) and len(src)>3:
        # Technical labels and code-only strings are often legitimately left untouched.
        if re.search(r'\b[a-z]{3,}\b',src,re.I) and src.lower() not in {'fifo','lifo','hrms'} and not re.search(r'^[A-Z0-9_\-./ ]+$',src):
            issues.append('NO_ARABIC_REVIEW')
    if 'BLOCKED_EDIT' in r.get('blocked_reasons',[]):issues.append('BLOCKED_EDIT')
    for issue in sorted(set(issues)):
        qa.append({'App':r['app'],'Issue':issue,'Source':src,'Current_Arabic':new,'Original_Arabic':old,'Context':r['context'],'Source_Location':r['location'],'Severity':'HIGH' if issue in {'BRACE_PLACEHOLDERS','PRINTF_PLACEHOLDERS','HTML_TAG_SET'} else 'MEDIUM' if issue in {'UNTRANSLATED','BOUNDARY_WHITESPACE'} else 'LOW','Suggested_Action':'مراجعة المتغيرات/الوسوم وربطها بالأصل قبل النشر' if issue in {'BRACE_PLACEHOLDERS','PRINTF_PLACEHOLDERS','HTML_TAG_SET'} else 'ترجمة ومراجعة حسب سياق الشاشة' if issue=='UNTRANSLATED' else 'مراجعة بشرية موجّهة'})
with (OUT/'Translation_Review_Queue.csv').open('w',encoding='utf-8-sig',newline='') as f:
    cols=list(qa[0]);w=csv.DictWriter(f,fieldnames=cols,lineterminator='\n');w.writeheader();w.writerows(qa)

stats={}
for app in ('frappe','erpnext','hrms'):
    part=[r for r in rows if r['app']==app]
    stats[app]={'rows':len(part),'original_empty':sum(not r['old'].strip() for r in part),'current_empty':sum(not r['new'].strip() for r in part),'changed':sum(r['old']!=r['new'] for r in part),'newly_translated':sum(not r['old'].strip() and bool(r['new'].strip()) for r in part),'nonempty_changed':sum(bool(r['old'].strip()) and r['old']!=r['new'] for r in part),'current_high_risk_count':sum(bool(set(risk_counts(r['src'],r['new']))&{'BRACE_PLACEHOLDERS','PRINTF_PLACEHOLDERS','HTML_TAG_SET'}) for r in part),'original_high_risk_count':sum(bool(set(risk_counts(r['src'],r['old']))&{'BRACE_PLACEHOLDERS','PRINTF_PLACEHOLDERS','HTML_TAG_SET'}) for r in part)}
rule_counts=collections.Counter(c for r in rows for c in r['changes'])
qa_counts=collections.Counter(q['Issue'] for q in qa)
report={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':source_fingerprints,'outputs':output_files,'counts':stats,'rule_counts':dict(rule_counts),'qa_issue_counts':dict(qa_counts),'glossary_rows':len(formal_gloss),'translation_memory_rows':len(phrase_memory),'change_log_rows':len(changelog),'review_queue_rows':len(qa),'editorial_scope':'Curated exact-label corrections + context-aware deterministic normalization; NOT a line-by-line expert verification of all 20,864 strings','formal_business_approval':'NOT_OBTAINED'}
(OUT/'QA_Summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

# Validate schema, identical msgid/msgctxt and notes/locations, and lossless CSV roundtrip.
for app,filename in output_files.items():
    original=[r for r in rows if r['app']==app]
    with (OUT/filename).open(encoding='utf-8-sig',newline='') as f:
        rdr=csv.DictReader(f)
        assert rdr.fieldnames==HEADERS
        dat=list(rdr)
    assert len(dat)==len(original)
    for r,d in zip(original,dat):
        assert d[HEADERS[0]]==r['src']
        assert d[HEADERS[2]]==r['context']
        assert d[HEADERS[3]]==r['note']
        assert d[HEADERS[4]]==r['location']
        assert d[HEADERS[1]]==r['new']
        assert not set(risk_counts(r['src'],r['new']))-set(risk_counts(r['src'],r['old']))

REPORT_TEMPLATE = r'''# تقرير مراجعة وتوحيد التعريب — Frappe / ERPNext / HRMS

**التاريخ:** 1 نوفمبر 2026  
**إصدار العمل:** `ONYX_ARABIC_EDITORIAL_CANDIDATE_R1`  
**النطاق:** ملفات CSV الثلاثة المقدمة؛ لم يحدث اتصال بموقع ERPNext أو تغيير في تطبيقاته.  
**حالة الاعتماد:** مخرجات تحريرية مرشحة لاعتماد المؤسسة، وليست حزمة نشر إنتاجية أو شهادة مراجعة بشرية شاملة.

## الملخص التنفيذي

أُعيد إخراج جميع صفوف الترجمة بعد مراجعة مصطلحية وتصحيح محافظ للمفاتيح الواضحة، ورسائل أعطت المعنى الخطأ، وتكرار النص الإنجليزي بعد الترجمة العربية. **احتُفظ بالنص الأصلي والمفتاح السياقي وترتيب الصفوف والبيانات الوصفية دون تغيير.**

| التطبيق | السجلات | الترجمات الفارغة قبل | الترجمات المستكملة | الصفوف المعدلة | الترجمات الفارغة بعد | نسبة التعبئة بعد |
|---|---:|---:|---:|---:|---:|---:|
| Frappe | {frappe[rows]:,} | {frappe[original_empty]:,} | {frappe[newly_translated]:,} | {frappe[changed]:,} | {frappe[current_empty]:,} | {fpct:.1f}% |
| ERPNext | {erpnext[rows]:,} | {erpnext[original_empty]:,} | {erpnext[newly_translated]:,} | {erpnext[changed]:,} | {erpnext[current_empty]:,} | {epct:.1f}% |
| HRMS | {hrms[rows]:,} | {hrms[original_empty]:,} | {hrms[newly_translated]:,} | {hrms[changed]:,} | {hrms[current_empty]:,} | {hpct:.2f}% |
| **الإجمالي** | **{total_rows:,}** | **{old_empty:,}** | **{newly:,}** | **{changed:,}** | **{new_empty:,}** | **{totalpct:.1f}%** |

من إجمالي الخانات الخالية بعد التصحيح، توجد **{need_translation:,}** عبارة قابلة للترجمة لم تُستكمل. توجد أيضًا خانة أصلها مسافات فقط في ERPNext، ولا ينبغي ملؤها اعتباطيًا. وفي HRMS بقي المفتاح التقني `{{}} ` دون نص عربي، لأنه لا يحمل محتوى لغويًا مستقلًا.

## ما الذي تغير فعلًا؟

| نوع العمل | مرات تطبيق القاعدة على الصفوف* |
|---|---:|
| ضبط مصطلحات قاموس موحّد ومقابلات مباشرة | {glossary_exact:,} |
| ترجمة عبارات الواجهة والمساعدة المحددة بالكامل | {curated_phrases:,} |
| إصلاح رسائل كاملة ومفاتيح حساسة بحسب النص الإنجليزي | {full_messages:,} |
| إزالة تكرار الإنجليزي الملحق بالنص العربي | {echo:,} |
| توحيد كلمة مخزن في سياق Warehouse | {warehouse:,} |
| ضبط إهلاك الأصول في سياق Depreciation | {depr:,} |
| توحيد التشغيلات المخزنية في سياق Batch | {batch:,} |
| إعادة المسافات الوظيفية في أطراف بعض العبارات | {whitespace:,} |

*قد يجتمع أكثر من نوع تغيير في الصف نفسه؛ مجموع تكرارات القواعد ليس عدد الصفوف المعدلة. العدد الدقيق للصفوف المعدلة هو **{changed:,}**، منها **{newly:,}** صفًا ملئت ترجمتها لأول مرة و**{revised:,}** صفًا تغيرت ترجمته السابقة.

### أمثلة تم تصحيحها

| المصدر الإنجليزي | قبل | بعد |
|---|---|---|
| `Draft` | مشروع | مسودة |
| `Payment Entry` | تدوينات المدفوعات | سند قبض/صرف/تحويل |
| `Stock Entry` | قيد مخزون | حركة مخزون |
| `Valuation Rate` | سعر التقييم | معدل تقييم المخزون |
| `Batch` | الدفعات | تشغيلة |
| `Journal Entry` | القيود اليومية | قيد يومية |
| `Salary Slip` | قسيمة الراتب | كشف راتب |
| `Role` | صلاحية | دور |

راجع `Translation_Change_Log.csv` للحصول على **كل** تعديل مع `msgid` و`msgctxt` والنص السابق واللاحق وقاعدة التعديل وموقع المصدر حيث توفر.

## القاموس الاصطلاحي وذاكرة الترجمة

- `Terminology_Glossary_AR.csv`: **{glossary_count:,} مصطلحًا** يغطّي البنية التقنية، الحسابات، المبيعات والمشتريات، المخزون والتصنيع، الأصول، الرواتب والمشاريع. كل مدخل يوضح المجال والسياق والصيغة المفضلة والبدائل المرفوضة حيث يلزم وحالة الاعتماد.
- `Curated_Translation_Memory_AR.csv`: **{memory_count:,} عبارة** لعبارات المساعدة والأوامر الكاملة. فصلنا هذه الذاكرة عن مصطلحات الأعمال حتى لا تختلط ترجمة جملة كاملة بمصطلح مفرد.
- **القاموس ليس معتمدًا إداريًا بعد:** `PROPOSED_EDITORIAL_STANDARD` يعني معيارًا تحريريًا مقترحًا، و`REQUIRES_DOMAIN_OWNER_APPROVAL` يتطلب موافقة المالك المختص. لا يجوز افتراض أن المراجعة الآلية تمثل توقيع مدير المالية أو HR.

قرارات مفاهيمية مؤثرة: `Submit` في دورة مستندات Frappe يعني تثبيت المستند (ليس موافقة إدارية تلقائيًا)، و`Item` بمعنى «صنف» في المخزون لكن قد يعني «عنصرًا» في واجهة عامة، و`Batch` «تشغيلة» في التتبع المخزني لا «دفعة سداد»، و`Budget` «موازنة» بينما `Balance Sheet` «ميزانية عمومية».

## الاختبارات التي نُفذت

1. فحص استعادة ملفات CSV عبر UTF-8 BOM، مع الحفاظ على **{total_rows:,}** سجلًا وترتيبها وأعمدتها الخمسة.
2. مقارنة `msgid` و`msgctxt` حرفيًا مع المصدر لكل صف؛ **لم يتغير أي مفتاح أو سياق**.
3. مقارنة `Description / Note` و`Source Location` للملفين التفصيليين؛ **لم تتغير**. وفي HRMS لم توجد بيانات وصف أو مسار في الملف الموحد، فتركت حقولها فارغة بلا اختلاق.
4. اختبار المتغيرات البرمجية (`{{0}}` و`{{name}}` و`%s` ونحوها)، وأعداد وسوم HTML، والمسافات الطرفية. لم يُدخل أي تغيير تراجعًا جديدًا وفق المدقّق المستخدم.
5. بعد التعديلات، **{risk_now}** حالات عدم تطابق مكتشف بواسطة فحص المتغيرات ووسوم HTML الأساسي؛ كانت **{risk_before}** حالة تحتوي على إنذارات من هذا النوع قبل التصحيح. هذا فحص آلي محدود وليس بديلًا عن اختبار التطبيق.
6. فحص تعارض الترجمات لنفس (`msgid`, `msgctxt`) عبر الملفات، مع الحفاظ على سجل تغيير قابل للرجوع.

## الفجوات المتبقية وخطة الاعتماد

- **{need_translation:,}** عبارة دون ترجمة فعلية: Frappe **{f_untranslated:,}** وERPNext **{e_untranslated:,}** وHRMS **{h_untranslated:,}**. لم تُستبدل باجتهادات واسعة غير معتمدة.
- **{no_arabic:,}** عبارة تحتوي نصًا لاتينيًا دون أحرف عربية وتحتاج فحصًا لمعرفة ما إذا كانت تسميات تقنية يجب عدم ترجمتها؛ العدد **ليس عدد أخطاء مؤكدة**.
- **{boundaries:,}** حالة متبقية تتطلب مراجعة لطريقة حفظ الأسطر/المسافات في قالب يتضمن HTML.
- اختبار ظهور النص في واجهة Desk، واتجاه RTL، وتنسيقات الطباعة، وصلاحية المعاني المحاسبية والموارد البشرية **لم يُنفذ على الموقع الفعلي**.
- لم تُراجع جميع الترجمات المعبأة مراجعة لغوية بشرية سطرًا بسطر. الملفات الصحيحة نحويًا قد تحتفظ بأخطاء دلالية سابقة.
- ملف `Translation_Review_Queue.csv` يوثق المسائل المعلّقة بالسبب والشدة والمصدر والسياق؛ المعالجة حسب أولوية الشاشات لا حسب ترتيب الملف.

## كيفية استخدام الملفات دون تعريض الإنتاج للخطر

الملفات الثلاثة المصححة **ملفات مرجعية قابلة للتدقيق بخمسة أعمدة** وليست تلقائيًا ملفات `translations/ar.csv` التشغيلية؛ توثيق Frappe للـCSV يستخدم أعمدة «النص المصدر، الترجمة، السياق». ويستخدم إصدار Frappe v16 ملفات PO/MO أيضًا، وهو ما يستلزم إثبات آلية النشر وأسبقية التطبيق على نسخة اختبار.

- لا تُنسخ هذه الملفات عشوائيًا إلى مجلدات التطبيقات الأساسية، ولا تُستورد في Desk كسجلات أعمال.
- ابدأ باعتماد القاموس مصطلحيًا على الأقل للمحاسبة والمخزون والموارد البشرية.
- حوّل **المفاتيح المُعتمدة فقط** إلى الصيغة التي يثبت تحميلها، ثم تحقق من أسبقية الترجمة وقت التشغيل، ومن التراجع بإصدار Git.
- أعد توليد الفروق عند تحديث Frappe أو ERPNext أو HRMS، ولا تنسخ ترجمات إصدار سابق دون مقارنة المفاتيح.

المراجع الرسمية لمعيار النشر (للاطلاع فقط، لا تزعم اختبار بيئة العمل):
- https://docs.frappe.io/framework/user/en/guides/basics/translations
- https://docs.frappe.io/framework/user/en/bench/frappe-commands
- https://docs.frappe.io/framework/user/en/bench-compile-po-to-mo

## نتائج المخرجات

| الملف | الغرض |
|---|---|
| `Frappe_Arabic_Corrected.csv` | مرجع ترجمة Frappe المصحح |
| `ERPNext_Arabic_Corrected.csv` | مرجع ترجمة ERPNext المصحح |
| `HRMS_Arabic_Corrected.csv` | مرجع ترجمة HRMS المشتق من الملف الموحد |
| `Terminology_Glossary_AR.csv` | قاموس المصطلحات وحالات الموافقة |
| `Curated_Translation_Memory_AR.csv` | ذاكرة العبارات التحريرية |
| `Translation_Change_Log.csv` | سجل جميع التعديلات مع قبل/بعد |
| `Translation_Review_Queue.csv` | قائمة المراجعة والنواقص |
| `QA_Summary.json` | الإحصاءات وبصمات المصادر |
| `build.py` و`editorial_additions.txt` | إعادة إنتاج عملية التحويل للتدقيق |

**معيار الانتقال إلى الإنتاج:** استكمال مراجعة العبارات ذات الأثر التشغيلي، واعتماد القاموس من أصحاب الاختصاص، واجتياز اختبارات تحميل Frappe v16 وRTL والتقارير والطباعة. هذه أعمال لازمة للنشر، وليست نتيجة منفذة في هذا التقرير.
'''

# Report generation in Arabic; figures are computed exclusively from verified output data.
fmt=dict(frappe=stats['frappe'],erpnext=stats['erpnext'],hrms=stats['hrms'],
         fpct=100*(stats['frappe']['rows']-stats['frappe']['current_empty'])/stats['frappe']['rows'],
         epct=100*(stats['erpnext']['rows']-stats['erpnext']['current_empty'])/stats['erpnext']['rows'],
         hpct=100*(stats['hrms']['rows']-stats['hrms']['current_empty'])/stats['hrms']['rows'],
         total_rows=sum(x['rows'] for x in stats.values()),old_empty=sum(x['original_empty'] for x in stats.values()),
         new_empty=sum(x['current_empty'] for x in stats.values()),newly=sum(x['newly_translated'] for x in stats.values()),
         changed=len(changelog),revised=sum(x['nonempty_changed'] for x in stats.values()),
         totalpct=100*(sum(x['rows']-x['current_empty'] for x in stats.values())/sum(x['rows'] for x in stats.values())),
         need_translation=qa_counts['UNTRANSLATED'],f_untranslated=sum(q['App']=='frappe' and q['Issue']=='UNTRANSLATED' for q in qa),
         e_untranslated=sum(q['App']=='erpnext' and q['Issue']=='UNTRANSLATED' for q in qa),
         h_untranslated=sum(q['App']=='hrms' and q['Issue']=='UNTRANSLATED' for q in qa),
         no_arabic=qa_counts['NO_ARABIC_REVIEW'],boundaries=qa_counts['BOUNDARY_WHITESPACE'],
         glossary_count=len(formal_gloss),memory_count=len(phrase_memory),
         glossary_exact=rule_counts['GLOSSARY_EXACT']+rule_counts['EXPLICIT_CORRECTION'],
         curated_phrases=rule_counts['EDITORIAL_EXACT']+rule_counts['CURATED_UI_PHRASE'],
         full_messages=rule_counts['FULL_MESSAGE_VERIFIED'],echo=rule_counts['REMOVE_DUPLICATED_SOURCE_ECHO'],
         warehouse=rule_counts['WAREHOUSE_CONTEXT'],depr=rule_counts['DEPRECIATION_CONTEXT'],
         batch=rule_counts['BATCH_STOCK_CONTEXT'],whitespace=rule_counts['PRESERVE_FRAGMENT_WHITESPACE'],
         risk_now=sum(x['current_high_risk_count'] for x in stats.values()),
         risk_before=sum(x['original_high_risk_count'] for x in stats.values()))
report_text=REPORT_TEMPLATE.format(**fmt)
(OUT/'Translation_QA_Report_AR.md').write_text(report_text,encoding='utf-8')

# Single archive for convenience; maintain separately downloadable CSV assets.
package=[*output_files.values(),'Terminology_Glossary_AR.csv','Curated_Translation_Memory_AR.csv',
         'Translation_Change_Log.csv','Translation_Review_Queue.csv','Translation_QA_Report_AR.md',
         'QA_Summary.json','build.py','editorial_additions.txt']
with zipfile.ZipFile(OUT/'ONYX_Arabic_Translation_Review_Package_R1.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for fname in package:z.write(OUT/fname,arcname=fname)

print(json.dumps({'stats':stats,'rules':rule_counts,'qa':qa_counts,'glossary_count':len(formal_gloss),'phrase_memory_count':len(phrase_memory),'changes':len(changelog)},ensure_ascii=False,indent=2))
